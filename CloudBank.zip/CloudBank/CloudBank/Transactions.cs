﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace CloudBank
{
    class Transactions
    {

        double transAmount;
        int transID;
        string vendorName;
        private Random transDate = new Random();
        public static List<CheckingTransactions> CTransactions { get; set; }
        
        static Transactions()
        {
            var temp = new List<CheckingTransactions>();

           CTransactions = temp.OrderBy(i => i.Name).ToList();
        }

        static void AddTransaction(List<CheckingTransactions> CTransations)
        {
            CTransactions.Add(new AddingTransactions()
            {
                vendorName = "Bob's Burger",
                transDate = "12/12/14",
                transCost = "12",});

        
        }

       public DateTime RandomTransDate()
        {
            DateTime start = new DateTime(2018, 01, 01);
            int range = (DateTime.Today - start).Days;
            return start.AddDays(transDate.Next(range));
        }

        public void RandomTransCost()
        {
            Random r = new Random();
            double transCost = r.Next(1, 100);
        }

        public void GenerateTransactions()
        {
            

            
        }

    }

    public class CheckingTransactions
    {
    }
}