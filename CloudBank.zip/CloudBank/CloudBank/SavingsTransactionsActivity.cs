﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace CloudBank
{
    [Activity(Label = "SavingsTransactionsActivity")]
    public class SavingsTransactionsActivity : Activity
    {

        Button Back;
        Button Logout;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resources.Layout.CheckingTransactions);

            FindViewById<Button>(Resource.Id.btnBack).Click += OnBackClick;
            FindViewById<Button>(Resource.Id.btnLogout).Click += OnLogoutClick;

            

            var lv = FindViewById<ListView>(Resource.Id.lsvSavingsTransactions);
            lv.Adapter = new ArrayAdapter<Item>(this,);
          


            // Create your application here
        }

        void OnBackClick(object sender, EventArgs e)
        {
            var intent = new Intent(this, typeof(AccountsActivity));
            StartActivity(intent);
        }



        void OnLogoutClick(object sender, EventArgs e)
        {
            Finish();
        }
    }
}