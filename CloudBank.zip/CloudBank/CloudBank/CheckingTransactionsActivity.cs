﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;



namespace CloudBank
{
    [Activity(Label = "TransactionsActivity")]
    public class CheckingTransactionsActivity : Activity
    {

        Button Back;
        Button Logout;
        ListView lsvCheckingTransactions;
        List<string> transactions;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resources.Layout.CheckingTransactions);

            FindViewById<Button>(Resource.Id.btnBack.Click += OnBackClick;
            FindViewById<Button>(Resource.Id.btnLogout).Click += OnLogoutClick;
            lsvCheckingTransactions = FindViewById<ListView>(Resource.Id.lsvCheckingTransactions);

            transactions = new List<string>();
            transactions.Add("Bob's Burger");
            transactions.Add("Kwik Trip");
            transactions.Add("Burger Heaven");
            transactions.Add("Disc Golf World");

            ArrayAdapter<string> adapter = new ArrayAdapter<string>(this, Android.Resource.Layout.SimpleListItem1.lsvCheckingTransactions);
            lsvCheckingTransactions.Adapter = adapter;


               

        }

        void OnBackClick(object sender, EventArgs e)
        {
            var intent = new Intent(this, typeof(AccountsActivity));
            StartActivity(intent);
        }



        void OnLogoutClick(object sender, EventArgs e)
        {
            Finish();
        }
    }
}