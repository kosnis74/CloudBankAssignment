﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace CloudBank
{
    [Activity(Label = "LoginActivity")]
    public class LoginActivity : Activity
    {
        EditText txtPassword;
        EditText txtUsername;
        Button Login;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            SetContentView(Resources.Layout.Login);

            FindViewById<Button>(Resource.Id.btnLogin).Click += OnLoginClick;
            FindViewById<EditText>(Resource.Id.txtUsername);
            FindViewById<EditText>(Resource.Id.txtPassword);
        }

        void OnLoginClick (object sender, EventArgs e)
        {
            string username = FindViewById<EditText>(Resource.Id.txtUsername).Text;
            string password = FindViewById<EditText>(Resource.Id.txtPassword).Text;

            var intent = new Intent();
            intent.PutExtra("username", username);
            intent.PutExtra("password", password);

            SetResult(Result.Ok, intent);
            Finish();
        }
    }
}