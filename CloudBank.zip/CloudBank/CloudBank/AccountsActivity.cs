﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace CloudBank
{
    [Activity(Label = "AccountsActivity")]
    public class AccountsActivity : Activity
    {
        Button Logout;
        Button Checking;
        Button Savings;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resources.Layout.Accounts);

            FindViewById<Button>(Resource.Id.btnLogout).Click += OnLogoutClick;
            FindViewById<Button>(Resource.Id.btnChecking).Click += OnCheckingClick;
            FindViewById<Button>(Resource.Id.btnSavings).Click += OnSavingsClick;

           
        }

        void OnCheckingClick(object sender, EventArgs e)
        {

            var intent = new Intent(this, typeof(CheckingTransactionsActivity));
            StartActivity(intent);

            

        }

        void OnSavingsClick(object sender, EventArgs e)
        {
            var intent = new Intent(this, typeof(SavingsTransactionsActivity));
            StartActivity(intent);

        }


        void OnLogoutClick(object sender, EventArgs e)
        {
            Finish();
        }

    }
}