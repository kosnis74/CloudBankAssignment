﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace CloudBank
{

    



    class User
    {
        EditText txtUsername;
        EditText txtPassword;

        string username;
        string password;
        int userID;
        List<string> Accounts = new List<string>();

        string clouduser;

        public void Login()
        {
           
            if(txtUsername.Text != "clouduser")
            {
                var reason = string.Format("enter appropriate username", ex.Message);
                Toast.MakeText(this, reason, ToastLength.Long).Show();
            }
            else
            {
                return;
            }

            if(txtPassword.Text != "318")
            {
                var reason = string.Format("enter appropriate password", ex.Message);
                Toast.MakeText(this, reason, ToastLength.Long).Show();
            }
            else
            {
                return;
            }
        }

        public void Logout()
        {

        }

    }
}